import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {
  CURRENT_KEY_VERSION,
  ByokCryptoError,
  encryptByokKey,
  decryptByokKey,
  needsByokKeyMigration,
  migrateByokRecordInMemory,
} from './src/lib/intelligence/byokCrypto.ts';
import {
  normalizeBudgetTier,
  parseMaxMonthlyBudget,
  buildCreatorContextProfile,
} from './src/lib/intelligence/personalizationEngine.ts';
import { ServerStateStore } from './src/lib/serverStateStore.ts';
import { evaluateIntelligenceOutput } from './src/lib/intelligence/qualityValidator.ts';

// 1. All 5 Onboarding Budget Choices + Edge Cases + maxMonthlyBudget
assert.equal(normalizeBudgetTier('₹0 – Free only'), 'zero');
assert.equal(parseMaxMonthlyBudget('₹0 – Free only'), 0);

assert.equal(normalizeBudgetTier('Under ₹500/month'), 'low');
assert.equal(parseMaxMonthlyBudget('Under ₹500/month'), 500);

assert.equal(normalizeBudgetTier('₹500–₹1,000/month'), 'low');
assert.equal(parseMaxMonthlyBudget('₹500–₹1,000/month'), 1000);

assert.equal(normalizeBudgetTier('₹1,000–₹2,500/month'), 'flexible');
assert.equal(parseMaxMonthlyBudget('₹1,000–₹2,500/month'), 2500);

assert.equal(normalizeBudgetTier('₹2,500+/month'), 'flexible');
assert.equal(parseMaxMonthlyBudget('₹2,500+/month'), null);

assert.equal(normalizeBudgetTier('₹100'), 'low');
assert.equal(normalizeBudgetTier('₹1,500'), 'low');
assert.equal(normalizeBudgetTier('₹2,000'), 'flexible');
assert.equal(normalizeBudgetTier('₹10,000'), 'flexible');
assert.equal(normalizeBudgetTier('Free tools only'), 'zero');
assert.equal(normalizeBudgetTier('No budget'), 'zero');
assert.equal(normalizeBudgetTier(undefined), 'zero');

// 2. Zero-budget paid-tool guard remains intact
const zeroCtx = buildCreatorContextProfile({
  profile: {
    niche: 'History Documentaries',
    monthlyBudget: '₹0 – Free only',
    preferredLanguage: 'English',
  } as any,
});
assert.equal(zeroCtx.isZeroBudget, true);
assert.equal(zeroCtx.maxMonthlyBudget, 0);
const paidToolEval = evaluateIntelligenceOutput({
  taskType: 'content_pack',
  topic: 'Indus Valley Civilization',
  output: {
    titles: ['The Lost Cities of the Indus Valley'],
    hooks: ['What happened to the largest Bronze Age civilization?'],
    scriptSections: [{ heading: 'Intro', content: 'Edit your documentary in Adobe Premiere Pro.' }],
  },
  context: zeroCtx,
});
assert.equal(paidToolEval.passed, false);

// 3. BYOK Encryption, Transaction Migration & Retrieval Integration
const prevEnv = process.env.NODE_ENV;
const prevSecret = process.env.BYOK_ENCRYPTION_SECRET;
const prevLegacy = process.env.BYOK_ENCRYPTION_SECRET_LEGACY;
const prevKRev = process.env.K_REVISION;

async function runByokTests() {
  try {
    process.env.NODE_ENV = 'production';
    delete process.env.BYOK_ENCRYPTION_SECRET;
    delete process.env.CREATORFLOW_BYOK_SECRET;
    process.env.K_REVISION = 'rev-001';

    assert.throws(
      () => encryptByokKey({ uid: 'user-1', plainKey: 'AIzaSyDummyTestKey123456' }),
      (err: unknown) => err instanceof ByokCryptoError && err.code === 'BYOK_SECRET_MISSING'
    );

    process.env.BYOK_ENCRYPTION_SECRET = '0123456789abcdef0123456789abcdef_prod_secret';
    const encryptedV2 = encryptByokKey({ uid: 'user-1', plainKey: 'AIzaSyDummyTestKey123456' });
    assert.equal(encryptedV2.keyVersion, CURRENT_KEY_VERSION);
    assert.equal(needsByokKeyMigration(encryptedV2), false);

    process.env.K_REVISION = 'rev-002-new-deploy';
    assert.equal(decryptByokKey(encryptedV2, 'user-1'), 'AIzaSyDummyTestKey123456');

    // Construct v1 record encrypted with old secret
    const oldSecret = 'legacy-secret-at-least-16-chars';
    const v1Key = crypto.scryptSync(oldSecret, 'creatorflow-byok-v1:user-1', 32);
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', v1Key, iv);
    cipher.setAAD(Buffer.from('uid:user-1', 'utf8'));
    const ct = Buffer.concat([cipher.update('AIzaSyLegacyV1Key987654', 'utf8'), cipher.final()]);
    const legacyRecord = {
      uid: 'user-1',
      encryptedKey: ct.toString('base64'),
      iv: iv.toString('base64'),
      authTag: cipher.getAuthTag().toString('base64'),
      keyVersion: 1,
      keyLast4: '7654',
      maskedHint: 'AIza••••••••7654',
      selectedModel: 'gemini-2.5-flash' as const,
      status: 'connected' as const,
      lastTestedAt: null,
      lastError: null,
      lastDiagnostic: null,
      createdAt: '2026-01-01T00:00:00.000Z',
      updatedAt: '2026-01-01T00:00:00.000Z',
    };

    // Mock minimal Firestore transaction store to verify concurrency, idempotency, and preservation
    let storedDoc: any = { ...legacyRecord };
    let txWrites = 0;
    const mockDb: any = {
      collection: () => ({
        doc: () => ({
          get: async () => ({ exists: Boolean(storedDoc), data: () => ({ ...storedDoc }) }),
        }),
      }),
      runTransaction: async (fn: any) => {
        const tx = {
          get: async () => ({ exists: Boolean(storedDoc), data: () => ({ ...storedDoc }) }),
          set: (_ref: any, data: any) => {
            txWrites += 1;
            storedDoc = { ...data };
          },
        };
        return fn(tx);
      },
    };

    const store = new ServerStateStore(mockDb);

    // Without legacy secret: migration fails safely & preserves v1 record untouched
    delete process.env.BYOK_ENCRYPTION_SECRET_LEGACY;
    const failedFetch = await store.getByokCredential('user-1');
    assert.equal(failedFetch?.keyVersion, 1);
    assert.equal(txWrites, 0);

    // With legacy secret: concurrent getByokCredential calls migrate once via transaction
    process.env.BYOK_ENCRYPTION_SECRET_LEGACY = oldSecret;
    const [r1, r2] = await Promise.all([
      store.getByokCredential('user-1'),
      store.getByokCredential('user-1'),
    ]);
    assert.equal(r1?.keyVersion, CURRENT_KEY_VERSION);
    assert.equal(r2?.keyVersion, CURRENT_KEY_VERSION);
    assert.equal(txWrites, 1);

    // Subsequent retrieval does not re-migrate v2 record
    const r3 = await store.getByokCredential('user-1');
    assert.equal(r3?.keyVersion, CURRENT_KEY_VERSION);
    assert.equal(txWrites, 1);
    assert.equal(decryptByokKey(r3!, 'user-1'), 'AIzaSyLegacyV1Key987654');
  } finally {
    process.env.NODE_ENV = prevEnv;
    if (prevSecret !== undefined) process.env.BYOK_ENCRYPTION_SECRET = prevSecret;
    else delete process.env.BYOK_ENCRYPTION_SECRET;
    if (prevLegacy !== undefined) process.env.BYOK_ENCRYPTION_SECRET_LEGACY = prevLegacy;
    else delete process.env.BYOK_ENCRYPTION_SECRET_LEGACY;
    if (prevKRev !== undefined) process.env.K_REVISION = prevKRev;
    else delete process.env.K_REVISION;
  }
}

runByokTests().then(() => {
  console.log('Stage 1 P0 final regression tests passed.');
});