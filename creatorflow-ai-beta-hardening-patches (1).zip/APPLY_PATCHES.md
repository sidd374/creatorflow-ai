# CreatorFlow AI — Beta Hardening Patch Bundle (Stages 1–4)

Included files:
1. `byokCrypto.ts` -> Replace `src/lib/intelligence/byokCrypto.ts`
2. `test-stage1-p0-fixes.ts` -> Add to repository root (`./test-stage1-p0-fixes.ts`)
3. `stage1-p0-fixes.patch` -> Apply changes to `server.ts`, `src/lib/serverStateStore.ts`, `src/lib/intelligence/types.ts`, and `src/lib/intelligence/personalizationEngine.ts`
4. `stage2-p1-security-fixes.patch` -> Apply P1 auth, quota reservation, rate-limit, OAuth `state`, and tour-progress whitelist fixes to `server.ts` and `src/lib/serverStateStore.ts`
5. `stage3-intelligence-and-research.patch` -> Apply fixes to `src/lib/intelligence/personalizationEngine.ts`, `qualityValidator.ts`, `webResearchEngine.ts`, and `pipeline.ts`
6. `stage4-guided-workflow.patch` -> Apply Guided Workflow fixes to `src/components/guidedWorkflow/GuidedWorkflowShell.tsx`

## Verify Locally Before Republishing
```bash
git checkout -b release/beta-hardening
npx tsx test-stage1-p0-fixes.ts
npm test
npm run lint
npm run build
```

## Required Production Environment Variables
- `BYOK_ENCRYPTION_SECRET` (32+ chars, required)
- `BYOK_ENCRYPTION_SECRET_LEGACY` (optional, for migrating existing v1 BYOK keys)
- `CREATORFLOW_REQUIRE_FIRESTORE="true"`
- `FIREBASE_PROJECT_ID`
- `FIRESTORE_DATABASE_ID`
- `OWNER_EMAIL`
- `APP_URL`
- `CASHFREE_APP_ID`, `CASHFREE_SECRET_KEY`, `CASHFREE_ENV` (if billing is enabled)
