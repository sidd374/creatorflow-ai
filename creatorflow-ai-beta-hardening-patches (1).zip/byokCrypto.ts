/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * Server-side AES-256-GCM encryption & masking for user BYOK Gemini API keys.
 * NEVER import this file in browser/client modules.
 */

import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import type { ByokKeyStatus, EncryptedByokRecord, GeminiDiagnosticInfo, GeminiModelId } from './types.ts';
import { normalizeGeminiModel } from './models.ts';

export const CURRENT_KEY_VERSION = 2;
const MIN_SUPPORTED_KEY_VERSION = 1;
const MIN_PRODUCTION_SECRET_LENGTH = 32;
const DEV_SALT_FILE = path.resolve(process.cwd(), '.creatorflow-key-salt');

export class ByokCryptoError extends Error {
  public readonly code: string;

  constructor(code: string, message: string) {
    super(message);
    this.name = 'ByokCryptoError';
    this.code = code;
  }
}

function resolveMasterSecret(): string {
  const configured =
    process.env.BYOK_ENCRYPTION_SECRET ||
    process.env.CREATORFLOW_BYOK_SECRET ||
    '';
  const trimmed = configured.trim();

  if (process.env.NODE_ENV === 'production') {
    if (trimmed.length < MIN_PRODUCTION_SECRET_LENGTH) {
      throw new ByokCryptoError(
        'BYOK_SECRET_MISSING',
        `BYOK_ENCRYPTION_SECRET (minimum ${MIN_PRODUCTION_SECRET_LENGTH} characters) is required in production. Refusing to derive a fallback encryption key.`
      );
    }
    return trimmed;
  }

  if (trimmed.length >= 16) {
    return trimmed;
  }

  // In local development / isolated test runs, persist a local random salt in gitignored file so restarts can decrypt saved test keys.
  try {
    if (fs.existsSync(DEV_SALT_FILE)) {
      const existing = fs.readFileSync(DEV_SALT_FILE, 'utf8').trim();
      if (existing.length >= 32) {
        return existing;
      }
    }
    const generated = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(DEV_SALT_FILE, generated, { mode: 0o600 });
    return generated;
  } catch {
    return 'cf_local_ephemeral_dev_encryption_secret_v1';
  }
}

function resolveLegacyMasterSecret(): string | null {
  const legacy =
    process.env.BYOK_ENCRYPTION_SECRET_LEGACY ||
    process.env.BYOK_LEGACY_ENCRYPTION_SECRET ||
    '';
  const trimmed = legacy.trim();
  return trimmed.length >= 16 ? trimmed : null;
}

function validateRecordKeyVersion(rawVersion: unknown): number {
  const version = rawVersion === undefined || rawVersion === null ? 1 : rawVersion;
  if (
    typeof version !== 'number' ||
    !Number.isInteger(version) ||
    version < MIN_SUPPORTED_KEY_VERSION ||
    version > CURRENT_KEY_VERSION
  ) {
    throw new ByokCryptoError(
      'BYOK_UNSUPPORTED_KEY_VERSION',
      `Unsupported BYOK credential keyVersion (${String(rawVersion)}). Supported versions: ${MIN_SUPPORTED_KEY_VERSION}..${CURRENT_KEY_VERSION}.`
    );
  }
  return version;
}

function deriveEncryptionKey(uid: string, keyVersion: number, masterSecret: string): Buffer {
  return crypto.scryptSync(masterSecret, `creatorflow-byok-v${keyVersion}:${uid}`, 32);
}

function decryptWithKey(record: EncryptedByokRecord, uid: string, key: Buffer): string {
  const iv = Buffer.from(record.iv, 'base64');
  const authTag = Buffer.from(record.authTag, 'base64');
  const encrypted = Buffer.from(record.encryptedKey, 'base64');

  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAAD(Buffer.from(`uid:${uid}`, 'utf8'));
  decipher.setAuthTag(authTag);

  const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
  return decrypted.toString('utf8');
}

export function validateGeminiApiKeyFormat(rawKey: unknown): {
  valid: boolean;
  cleaned: string;
  error?: string;
} {
  if (typeof rawKey !== 'string') {
    return { valid: false, cleaned: '', error: 'API key must be a string.' };
  }
  const cleaned = rawKey
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .trim()
    .replace(/^["'`]+|["'`]+$/g, '')
    .trim();
  if (!cleaned) {
    return { valid: false, cleaned: '', error: 'Gemini API key cannot be empty.' };
  }
  if (/\s/.test(cleaned)) {
    return {
      valid: false,
      cleaned: '',
      error: 'Gemini API key cannot contain spaces or line breaks.',
    };
  }
  if (!/^[\x21-\x7E]+$/.test(cleaned)) {
    return {
      valid: false,
      cleaned: '',
      error: 'Gemini API key contains invalid hidden or non-ASCII characters. Please copy and paste the raw key again.',
    };
  }
  if (cleaned.length < 12 || cleaned.length > 512) {
    return {
      valid: false,
      cleaned: '',
      error: 'Gemini API key length looks invalid. Paste your full key without extra text.',
    };
  }
  return { valid: true, cleaned };
}

export function maskGeminiApiKey(plainKey: string): {
  keyLast4: string;
  maskedHint: string;
} {
  const cleaned = plainKey.trim();
  const keyLast4 = cleaned.slice(-4);
  const prefix = cleaned.length > 8 ? cleaned.slice(0, 4) : '';
  return {
    keyLast4,
    maskedHint: `${prefix}${'•'.repeat(8)}${keyLast4}`,
  };
}

export function encryptByokKey(params: {
  uid: string;
  plainKey: string;
  selectedModel?: GeminiModelId;
  status?: ByokKeyStatus;
  lastTestedAt?: string | null;
  lastError?: string | null;
  lastDiagnostic?: GeminiDiagnosticInfo | null;
  existingCreatedAt?: string;
}): EncryptedByokRecord {
  const { uid, plainKey } = params;
  const master = resolveMasterSecret();
  const key = deriveEncryptionKey(uid, CURRENT_KEY_VERSION, master);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  cipher.setAAD(Buffer.from(`uid:${uid}`, 'utf8'));
  const encrypted = Buffer.concat([cipher.update(plainKey, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  const { keyLast4, maskedHint } = maskGeminiApiKey(plainKey);
  const nowIso = new Date().toISOString();

  return {
    uid,
    encryptedKey: encrypted.toString('base64'),
    iv: iv.toString('base64'),
    authTag: authTag.toString('base64'),
    keyVersion: CURRENT_KEY_VERSION,
    keyLast4,
    maskedHint,
    selectedModel: normalizeGeminiModel(params.selectedModel),
    status: params.status || 'connected',
    lastTestedAt: params.lastTestedAt ?? null,
    lastError: params.lastError ?? null,
    lastDiagnostic: params.lastDiagnostic ?? null,
    createdAt: params.existingCreatedAt || nowIso,
    updatedAt: nowIso,
  };
}

export function decryptByokKey(record: EncryptedByokRecord, uid: string): string {
  if (!record || record.uid !== uid) {
    throw new ByokCryptoError('BYOK_OWNERSHIP_MISMATCH', 'BYOK credential ownership mismatch.');
  }

  const recordVersion = validateRecordKeyVersion(record.keyVersion);
  const primaryMaster = resolveMasterSecret();
  const primaryKey = deriveEncryptionKey(uid, recordVersion, primaryMaster);

  try {
    return decryptWithKey(record, uid, primaryKey);
  } catch {
    // Only v1 credentials may attempt fallback decryption with an explicit legacy secret.
    if (recordVersion === 1) {
      const legacyMaster = resolveLegacyMasterSecret();
      if (legacyMaster) {
        try {
          const legacyKey = deriveEncryptionKey(uid, 1, legacyMaster);
          return decryptWithKey(record, uid, legacyKey);
        } catch {
          // Fall through to safe recovery error below without leaking secrets or ciphertext.
        }
      }
    }

    throw new ByokCryptoError(
      'BYOK_DECRYPTION_FAILED',
      `Unable to decrypt stored BYOK credential (keyVersion=${recordVersion}). If this v1 credential was encrypted with an earlier secret, configure BYOK_ENCRYPTION_SECRET_LEGACY or ask the user to re-save their Gemini API key in Settings.`
    );
  }
}

export function needsByokKeyMigration(record: EncryptedByokRecord): boolean {
  const version = validateRecordKeyVersion(record?.keyVersion);
  return version < CURRENT_KEY_VERSION;
}

/**
 * Pure in-memory migration helper: validates version, decrypts using current or explicit legacy secret,
 * and returns a v2 EncryptedByokRecord without mutating the input record or touching Firestore.
 * Callers must persist the returned record under ServerStateStore's per-uid lock (`withAccountLock`).
 */
export function migrateByokRecordInMemory(
  record: EncryptedByokRecord,
  uid: string
): { migrated: boolean; record: EncryptedByokRecord } {
  if (!needsByokKeyMigration(record)) {
    return { migrated: false, record };
  }

  const plainKey = decryptByokKey(record, uid);
  const reEncrypted = encryptByokKey({
    uid,
    plainKey,
    selectedModel: record.selectedModel,
    status: record.status,
    lastTestedAt: record.lastTestedAt,
    lastError: record.lastError,
    lastDiagnostic: record.lastDiagnostic,
    existingCreatedAt: record.createdAt,
  });

  return { migrated: true, record: reEncrypted };
}
